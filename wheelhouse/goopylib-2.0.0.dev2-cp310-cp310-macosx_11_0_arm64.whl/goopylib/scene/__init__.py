"""
goopylib module initialization
"""

from goopylib.scene.camera import Camera
