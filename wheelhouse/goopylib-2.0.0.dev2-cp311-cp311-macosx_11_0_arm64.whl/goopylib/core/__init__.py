"""
goopylib module initialization
"""

from goopylib.core import *
