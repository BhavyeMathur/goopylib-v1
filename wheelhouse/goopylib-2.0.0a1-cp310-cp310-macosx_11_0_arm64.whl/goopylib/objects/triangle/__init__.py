"""
Module defining a Triangle object
"""

from .triangle import *
