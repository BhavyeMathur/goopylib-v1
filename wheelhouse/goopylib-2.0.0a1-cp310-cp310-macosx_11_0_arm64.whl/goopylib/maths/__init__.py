"""
goopylib module initialization
"""
