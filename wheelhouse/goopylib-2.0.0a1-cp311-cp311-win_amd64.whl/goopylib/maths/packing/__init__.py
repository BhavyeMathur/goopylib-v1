"""
goopylib module initialization
"""

# TODO C++ documentation, type-checking, add errors to Python documentation
# TODO C++ extension for packing and shelf

from .packing import *
from . import shelf
