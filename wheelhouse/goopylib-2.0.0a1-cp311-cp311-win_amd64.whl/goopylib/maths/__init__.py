"""
goopylib module initialization
"""
