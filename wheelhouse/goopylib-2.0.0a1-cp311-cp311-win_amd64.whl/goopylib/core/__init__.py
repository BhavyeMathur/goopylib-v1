"""
goopylib module initialization
"""

from .core import *
from .window import *
