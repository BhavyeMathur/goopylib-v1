"""
Module defining a line object
"""

from .line import *
