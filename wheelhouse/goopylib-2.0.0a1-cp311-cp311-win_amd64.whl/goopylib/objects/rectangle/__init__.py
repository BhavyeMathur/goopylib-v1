"""
Module defining a Rectangle object
"""

from .rectangle import *
