"""
Module defining a Quad object
"""

from .quad import *
