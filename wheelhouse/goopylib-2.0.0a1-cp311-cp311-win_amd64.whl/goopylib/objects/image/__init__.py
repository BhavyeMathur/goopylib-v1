"""
Module defining an Image object
"""

from .image import *
