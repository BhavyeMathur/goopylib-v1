"""
Module defining an ellipse object
"""

from .ellipse import *
