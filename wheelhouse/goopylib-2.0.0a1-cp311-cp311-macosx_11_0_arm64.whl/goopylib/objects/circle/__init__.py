"""
Module defining a circle object
"""

from .circle import *
