"""
goopylib module initialization
"""

from .keyboard import *
from .mouse import *
