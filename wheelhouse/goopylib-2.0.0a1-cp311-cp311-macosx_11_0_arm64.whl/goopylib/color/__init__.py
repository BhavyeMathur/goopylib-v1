"""
goopylib module initialization
"""

from .color import *
