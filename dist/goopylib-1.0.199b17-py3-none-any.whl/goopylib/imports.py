from goopylib.styles import *
from goopylib.util import *
from goopylib.constants import *
from goopylib.colours import *

from goopylib.objects.imports import *
from goopylib.math.imports import *

import time
