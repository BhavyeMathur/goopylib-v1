from goopylib.math.BezierCurve import *
from goopylib.math.BSpline import *
from goopylib.math.Easing import *

import math
