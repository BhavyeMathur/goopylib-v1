from goopylib.objects.Oval import Oval
from goopylib.Point import Point
from goopylib._internal_classes import VectorEquation

class Circle(Oval):

    def __init__(self, center, radius, bounds=None, style=None, fill=None, outline=None,
                 outline_width=None, cursor="arrow", window=None):
        p1 = Point(center.x - radius, center.y - radius)
        p2 = Point(center.x + radius, center.y + radius)

        self.center = center

        self.radius = radius
        Oval.__init__(self, center, radius, radius, bounds=bounds, fill=fill, outline=outline, outline_width=outline_width, style=style,
                      cursor=cursor, window=window)

        self.equation = VectorEquation("(x-{})**2 + (y-{})**2 < {}**2".format(self.center.x, self.center.y, radius))

    def __repr__(self):
        return super().__repr__()

    def clone(self):
        other = Circle(self.get_anchor(), self.radius)
        other.config = self.config.copy()
        return other

    def get_radius(self):
        return self.radius

    def _update(self):
        self.equation = VectorEquation("(x-{})**2 + (y-{})**2 < {}**2".format(self.anchor.x, self.anchor.y,
                                                                              self.radius))
