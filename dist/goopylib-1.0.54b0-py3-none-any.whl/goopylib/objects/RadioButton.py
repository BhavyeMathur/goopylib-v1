class RadioButton:
    def __init__(self, **boxes):
        self.boxes = boxes

    def draw(self):
        pass

    def undraw(self):
        pass

    def redraw(self):
        pass

    def set_state(self):
        pass
