from goopylib.styles import *
from goopylib.util import *
from goopylib.constants import *

from goopylib.colours import *

from goopylib.objects.imports import *

from goopylib.math.BezierCurve import *
from goopylib.math.BSpline import *
from goopylib.math.Easing import *
from goopylib.math.Curves import *

from goopylib.applications.custom_ease import *

import math
import time
